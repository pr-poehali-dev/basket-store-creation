export const STAGES = ['Новый заказ', 'Согласование', 'Оплата', 'В очереди на плетение', 'Плетение',
  'Сушилка', 'Малярка', 'Упаковка', 'Доставка', 'Закрытые'];

export const QUEUE_INDEX     = STAGES.indexOf('В очереди на плетение');
export const WEAVING_INDEX   = STAGES.indexOf('Плетение');
export const DRYING_INDEX    = STAGES.indexOf('Сушилка');
export const PAINTING_INDEX  = STAGES.indexOf('Малярка');
export const PACKING_INDEX   = STAGES.indexOf('Упаковка');
export const CLOSED_STAGE    = 'Закрытые';

export interface OrderItem {
  name: string;
  size: string;
  color: string;
  qty: number;
}

export interface Order {
  id: number;
  order_number: string;
  stage: string;
  city: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  total: number;
  discount: number;
  items: OrderItem[];
  created_at: string | null;
  responsible: string;
  due_date: string;
  due_weaving: string;
  due_painting: string;
  delivery_type: string;
  delivery_address: string;
  payment_method: string;
  comment: string;
  notes: string;
  produced: Record<string, number>;
  painted: Record<string, number>;
  is_archived: boolean;
  is_trashed: boolean;
  form?: Record<string, string>;
}

export interface Position {
  key: string;
  title: string;
  total: number;
  colors: { color: string; qty: number }[];
}

// Отображаемое название позиции без размера в скобках (только для UI —
// сам title остаётся с размером и используется как ключ сопоставления со складом)
export function displayTitle(title: string): string {
  return title.replace(/\s*\([^)]*\)\s*$/, '').trim();
}

export function groupPositions(items: OrderItem[]): Position[] {
  const map = new Map<string, Position>();
  for (const it of items) {
    const key = `${it.name}__${it.size}`;
    const title = it.size ? `${it.name} (${it.size})` : it.name;
    if (!map.has(key)) {
      map.set(key, { key, title, total: 0, colors: [] });
    }
    const pos = map.get(key)!;
    pos.total += it.qty;
    const existing = pos.colors.find(c => c.color === it.color);
    if (existing) existing.qty += it.qty;
    else pos.colors.push({ color: it.color || '—', qty: it.qty });
  }
  return Array.from(map.values());
}

export function fmtDate(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function fmtDueDate(due: string): string {
  if (!due) return '';
  const d = new Date(due + 'T00:00:00');
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

export function fmtDateShort(due: string): string {
  if (!due) return '';
  const d = new Date(due + 'T00:00:00');
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function fmtMoney(n: number): string {
  return n.toLocaleString('ru-RU') + ' руб';
}

export const RESPONSIBLES: { name: string; bg: string; text: string }[] = [
  { name: 'Валера',   bg: '#cfe3f0', text: '#2c5773' },
  { name: 'Кристина', bg: '#d4e8d0', text: '#3f6b3a' },
  { name: 'Таня',     bg: '#f0d6df', text: '#834759' },
];

export function responsibleStyle(name: string) {
  return RESPONSIBLES.find(r => r.name === name);
}

export const DELIVERY_TYPES: Record<string, string> = {
  'тк': 'ТК',
  'ати': 'АТИ',
  'смв': 'СМВ',
};

export const DELIVERY_LABELS: Record<string, string> = {
  'тк': 'Транспортная компания',
  'ати': 'Частный перевозчик до адреса',
  'смв': 'Самовывоз',
};

export function daysUntil(due: string): number | null {
  if (!due) return null;
  const d = new Date(due + 'T00:00:00');
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

// Статус дедлайна для карточки:
// 'burn-weaving'  — сегодня или просрочен дедлайн плетения, заказ ещё до Малярки
// 'burn-painting' — сегодня или просрочен дедлайн покраски, заказ ещё до Упаковки
// 'warn-weaving'  — 1 день до дедлайна плетения (до Малярки)
// 'warn-painting' — 1 день до дедлайна покраски (до Упаковки)
// null — всё в норме
export type DeadlineStatus =
  | 'burn-weaving'
  | 'burn-painting'
  | 'warn-weaving'
  | 'warn-painting'
  | null;

export function getDeadlineStatus(order: Order): DeadlineStatus {
  const stageIdx = STAGES.indexOf(order.stage);

  if (order.due_weaving && stageIdx >= QUEUE_INDEX && stageIdx < PAINTING_INDEX) {
    const left = daysUntil(order.due_weaving);
    if (left !== null && left <= 0) return 'burn-weaving';
    if (left !== null && left === 1) return 'warn-weaving';
  }

  if (order.due_painting && stageIdx >= QUEUE_INDEX && stageIdx < PACKING_INDEX) {
    const left = daysUntil(order.due_painting);
    if (left !== null && left <= 0) return 'burn-painting';
    if (left !== null && left === 1) return 'warn-painting';
  }

  return null;
}

// Нужна ли заказу покраска (есть хотя бы одна позиция с цветом, отличным от «натуральный»)
export function needsPainting(order: Order): boolean {
  return order.items.some(it => {
    const color = (it.color || '').toLowerCase().trim();
    return color !== '' && color !== 'натуральный';
  });
}

// Процент плетения для заказа (из produced)
export function weavingPct(order: Order): number {
  const positions = groupPositions(order.items);
  const totalQty = positions.reduce((s, p) => s + p.total, 0);
  if (totalQty === 0) return 0;
  const totalDone = positions.reduce((s, p) =>
    s + Math.min((order.produced || {})[p.key] || 0, p.total), 0);
  return Math.round((totalDone / totalQty) * 100);
}

// Процент покраски (из painted по ключам позиций).
// Натуральный цвет (и позиции без цвета) не требуют покраски — их количество
// не учитывается ни в знаменателе, ни в числителе процента.
export function paintingPct(order: Order): number {
  const neededByKey: Record<string, number> = {};
  for (const it of order.items) {
    const color = (it.color || '').toLowerCase().trim();
    if (color === '' || color === 'натуральный') continue;
    const key = `${it.name}__${it.size}`;
    neededByKey[key] = (neededByKey[key] || 0) + it.qty;
  }
  const painted = order.painted || {};
  let totalQty = 0, totalPainted = 0;
  for (const key in neededByKey) {
    const needed = neededByKey[key];
    totalQty += needed;
    totalPainted += Math.min(painted[key] || 0, needed);
  }
  if (totalQty === 0) return 100; // красить нечего — считаем выполненным
  return Math.round((totalPainted / totalQty) * 100);
}

// Можно ли перейти на следующий этап (блокировка по 100% и по обязательным срокам)
export function canAdvanceStage(order: Order, targetStage: string): { ok: boolean; reason?: string } {
  // Из «В очереди на плетение» нельзя двигаться дальше без проставленных сроков
  if (order.stage === 'В очереди на плетение') {
    if (!order.due_weaving) {
      return { ok: false, reason: 'Не проставлен срок плетения — заполните его в карточке заказа.' };
    }
    if (needsPainting(order) && !order.due_painting) {
      return { ok: false, reason: 'Не проставлен срок окраски — заполните его в карточке заказа.' };
    }
  }
  if (targetStage === 'Сушилка') {
    const pct = weavingPct(order);
    if (pct < 100) return { ok: false, reason: `Плетение ${pct}% — нужно 100% для перехода в Сушилку.` };
  }
  if (targetStage === 'Упаковка') {
    if (!needsPainting(order)) {
      // Красить нечего (только натуральный) — Малярка пропускается,
      // но плетение всё равно должно быть завершено на 100%.
      const pct = weavingPct(order);
      if (pct < 100) return { ok: false, reason: `Плетение ${pct}% — нужно 100% для перехода в Упаковку.` };
    } else {
      const pct = paintingPct(order);
      if (pct < 100) return { ok: false, reason: `Покраска ${pct}% — нужно 100% для перехода в Упаковку.` };
    }
  }
  return { ok: true };
}