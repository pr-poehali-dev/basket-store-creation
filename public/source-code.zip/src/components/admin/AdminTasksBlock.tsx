import { useState, useEffect, useCallback, useMemo } from 'react';
import Icon from '@/components/ui/icon';
import urls from '../../../backend/func2url.json';
import { Order } from './orderUtils';
import OrderFullCard from './OrderFullCard';
import TaskDetailModal from './TaskDetailModal';
import {
  Task, TaskRequest, StaffOption, AuthData,
  TaskStatus, TaskPriority, ReqType, ViewMode, TabKey, TaskSubTab, PeriodFilter,
  PRIORITY_LABEL, PRIORITY_COLOR, STATUS_LABEL, STATUS_COLOR,
  REQ_TYPE_LABEL, REQ_STATUS_LABEL, KANBAN_COLS,
  fmtDate, isoToday, matchesPeriod, isNotification,
} from './tasksUtils';

export type { AuthData };

// ── Форма новой задачи ────────────────────────────────────────────────────────
const TaskForm = ({ auth, staff, onSave, onClose }: {
  auth: AuthData;
  staff: StaffOption[];
  onSave: (task: Partial<Task>) => Promise<void>;
  onClose: () => void;
}) => {
  const [title, setTitle]       = useState('');
  const [desc, setDesc]         = useState('');
  const [assignTo, setAssignTo] = useState<number | ''>('');
  const [dueDate, setDueDate]   = useState('');
  const [priority, setPriority] = useState<TaskPriority>('normal');
  const [saving, setSaving]     = useState(false);

  // Группируем: у кого есть кабинет — в группу «Плетельщики», остальные — по своим группам
  const groups: Record<string, StaffOption[]> = {};
  for (const s of staff.filter(s => s.is_active)) {
    const hasCabinet = (s.pages || []).includes('cabinet');
    const groupKey = hasCabinet ? 'Плетельщики' : s.group_name;
    if (!groups[groupKey]) groups[groupKey] = [];
    groups[groupKey].push(s);
  }

  const submit = async () => {
    if (!title.trim()) return;
    setSaving(true);
    await onSave({
      title: title.trim(),
      description: desc,
      assigned_to: assignTo !== '' ? Number(assignTo) : null,
      assigned_by: auth.staff_id || null,
      assigned_by_name: auth.full_name || 'Администратор',
      due_date: dueDate,
      priority,
    });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-background rounded-2xl border border-primary/30 p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <h3 className="font-semibold text-primary text-lg mb-4">Новая задача</h3>
        <div className="space-y-3">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Название задачи *"
            className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent" />
          <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Описание (необязательно)" rows={2}
            className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent resize-none" />

          {/* Выбор по подразделениям */}
          <select value={assignTo} onChange={e => setAssignTo(e.target.value === '' ? '' : Number(e.target.value))}
            className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent">
            <option value="">— Кому (всем) —</option>
            {Object.entries(groups).map(([group, members]) => (
              <optgroup key={group} label={group}>
                {members.map(s => <option key={s.id} value={s.id}>{s.full_name}</option>)}
              </optgroup>
            ))}
          </select>

          <div className="flex gap-2">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground block mb-1">Дедлайн</label>
              <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)}
                className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent" />
            </div>
            <div className="flex-1">
              <label className="text-xs text-muted-foreground block mb-1">Приоритет</label>
              <select value={priority} onChange={e => setPriority(e.target.value as TaskPriority)}
                className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent">
                {(Object.keys(PRIORITY_LABEL) as TaskPriority[]).map(p => (
                  <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          <button onClick={submit} disabled={saving || !title.trim()}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-2.5 rounded-xl text-sm disabled:opacity-50">
            {saving ? 'Сохраняю...' : 'Создать'}
          </button>
          <button onClick={onClose} className="px-4 py-2.5 rounded-xl border border-primary/30 text-primary text-sm">Отмена</button>
        </div>
      </div>
    </div>
  );
};

// ── Форма заявки ──────────────────────────────────────────────────────────────
const RequestForm = ({ auth, onSave, onClose }: {
  auth: AuthData;
  onSave: (req: Partial<TaskRequest>) => Promise<void>;
  onClose: () => void;
}) => {
  const [reqType, setReqType] = useState<ReqType>('dayoff');
  const [comment, setComment] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo]   = useState('');
  const [saving, setSaving]   = useState(false);

  const submit = async () => {
    setSaving(true);
    await onSave({ staff_id: auth.staff_id, staff_name: auth.full_name || '', request_type: reqType, comment, date_from: dateFrom, date_to: dateTo });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-background rounded-2xl border border-primary/30 p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <h3 className="font-semibold text-primary text-lg mb-4">Заявка</h3>
        <div className="space-y-3">
          <select value={reqType} onChange={e => setReqType(e.target.value as ReqType)}
            className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent">
            {(Object.keys(REQ_TYPE_LABEL) as ReqType[]).map(t => <option key={t} value={t}>{REQ_TYPE_LABEL[t]}</option>)}
          </select>
          {reqType !== 'data_fix' && (
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-xs text-muted-foreground block mb-1">С</label>
                <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
                  className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent" />
              </div>
              <div className="flex-1">
                <label className="text-xs text-muted-foreground block mb-1">По</label>
                <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
                  className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent" />
              </div>
            </div>
          )}
          <textarea value={comment} onChange={e => setComment(e.target.value)}
            placeholder={reqType === 'data_fix' ? 'Опиши что нужно исправить...' : 'Комментарий (необязательно)'}
            rows={3} className="w-full border border-primary/30 rounded-xl px-3 py-2 text-sm outline-none focus:border-accent resize-none" />
        </div>
        <div className="flex gap-2 mt-4">
          <button onClick={submit} disabled={saving}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-2.5 rounded-xl text-sm disabled:opacity-50">
            {saving ? 'Отправляю...' : 'Отправить заявку'}
          </button>
          <button onClick={onClose} className="px-4 py-2.5 rounded-xl border border-primary/30 text-primary text-sm">Отмена</button>
        </div>
      </div>
    </div>
  );
};

// ── Одна карточка задачи ──────────────────────────────────────────────────────
const TaskCard = ({ task, onUpdateStatus, onOpen, onOpenOrder, compact }: {
  task: Task;
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  onOpen?: (task: Task) => void;
  onOpenOrder?: (orderId: number) => void;
  compact?: boolean;
}) => {
  const today = isoToday();
  const isOverdue = task.due_date && task.due_date < today && task.status !== 'done';
  return (
    <div onClick={() => onOpen?.(task)}
      className={`bg-card border rounded-2xl px-3 py-2.5 ${onOpen ? 'cursor-pointer' : ''} ${task.status === 'done' ? 'opacity-60' : ''} ${isOverdue ? 'border-red-300' : 'border-primary/25'}`}>
      <div className="flex items-start justify-between gap-2 mb-1">
        <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${PRIORITY_COLOR[task.priority]}`}>
          {PRIORITY_LABEL[task.priority]}
        </span>
        {task.due_date && (
          <span className={`text-[10px] font-medium flex-shrink-0 ${isOverdue ? 'text-red-500 font-bold' : 'text-primary/60'}`}>
            {isOverdue ? '⚠️ ' : ''}{fmtDate(task.due_date)}
          </span>
        )}
      </div>
      <div className="font-semibold text-primary text-sm leading-tight mb-1">{task.title}</div>
      {task.description && !compact && (
        <p className="text-xs text-primary/60 mb-1 line-clamp-2">{task.description}</p>
      )}
      {task.order_id && (
        <button onClick={e => { e.stopPropagation(); onOpenOrder?.(task.order_id!); }}
          className="mb-1 flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-accent/15 text-primary border border-accent/30 hover:bg-accent/25 transition-colors w-fit">
          📦 {task.order_city} {task.order_customer_name}
        </button>
      )}
      {/* Исполнитель и автор */}
      <div className="flex items-center justify-between mt-1.5 gap-2">
        <div className="text-[10px] text-primary/50 leading-tight">
          <span className="text-primary/70">→ {task.assignee_name || 'Все'}</span>
        </div>
        <select value={task.status} onChange={e => onUpdateStatus(task.id, e.target.value as TaskStatus)}
          onClick={e => e.stopPropagation()}
          className="text-[10px] border border-primary/25 rounded-lg px-1.5 py-0.5 bg-background outline-none text-primary flex-shrink-0 max-w-[100px]">
          {(Object.keys(STATUS_LABEL) as TaskStatus[]).map(s => (
            <option key={s} value={s}>{STATUS_LABEL[s]}</option>
          ))}
        </select>
      </div>
    </div>
  );
};

// ── Канбан ────────────────────────────────────────────────────────────────────
const KanbanView = ({ tasks, onUpdateStatus, onOpen, onOpenOrder }: {
  tasks: Task[];
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  onOpen: (task: Task) => void;
  onOpenOrder: (orderId: number) => void;
}) => (
  <div className="overflow-x-auto -mx-1 px-1">
    <div className="flex gap-4 min-w-max pb-2">
      {KANBAN_COLS.map(col => {
        const colTasks = tasks.filter(t => t.status === col);
        return (
          <div key={col} className="w-72 flex-shrink-0">
            <div className={`px-3 py-2 mb-3 rounded-xl border text-sm font-semibold text-center ${STATUS_COLOR[col]}`}>
              {STATUS_LABEL[col]} ({colTasks.length})
            </div>
            <div className="space-y-2">
              {colTasks.map(t => <TaskCard key={t.id} task={t} onUpdateStatus={onUpdateStatus} onOpen={onOpen} onOpenOrder={onOpenOrder} />)}
              {colTasks.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Нет задач</p>}
            </div>
          </div>
        );
      })}
    </div>
  </div>
);

// ── Список с сортировкой ───────────────────────────────────────────────────────
type SortCol = 'title' | 'due_date' | 'assignee_name' | 'assigned_by_name' | 'status' | 'priority';
const ListView = ({ tasks, onUpdateStatus, onOpen, onOpenOrder }: {
  tasks: Task[];
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  onOpen: (task: Task) => void;
  onOpenOrder: (orderId: number) => void;
}) => {
  const [sortCol, setSortCol] = useState<SortCol>('due_date');
  const [sortAsc, setSortAsc] = useState(true);
  const today = isoToday();

  const PRIORITY_ORDER: Record<TaskPriority, number> = { urgent: 0, high: 1, normal: 2, low: 3 };
  const STATUS_ORDER:   Record<TaskStatus,   number> = { pending: 0, in_progress: 1, done: 2, cancelled: 3 };

  const sorted = [...tasks].sort((a, b) => {
    let cmp = 0;
    if (sortCol === 'priority') cmp = PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    else if (sortCol === 'status') cmp = STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
    else if (sortCol === 'due_date') cmp = (a.due_date || '').localeCompare(b.due_date || '');
    else cmp = (a[sortCol] || '').localeCompare(b[sortCol] || '', 'ru');
    return sortAsc ? cmp : -cmp;
  });

  const th = (col: SortCol, label: string, extraClass = '') => (
    <th className={`px-3 py-2.5 text-left font-semibold cursor-pointer hover:text-primary select-none whitespace-nowrap ${extraClass}`}
      onClick={() => { if (sortCol === col) setSortAsc(v => !v); else { setSortCol(col); setSortAsc(true); } }}>
      {label} {sortCol === col ? (sortAsc ? '↑' : '↓') : <span className="opacity-30">↕</span>}
    </th>
  );

  return (
    <div className="border border-primary/20 rounded-2xl overflow-x-auto">
      <table className="w-full text-sm border-collapse min-w-[640px]">
        <thead>
          <tr className="bg-primary/5 text-xs text-primary/60 border-b border-primary/15">
            {th('title', 'Задача', 'min-w-[200px] sm:min-w-[240px]')}
            {th('due_date', 'Дедлайн')}
            {th('priority', 'Приоритет')}
            {th('assignee_name', 'Исполнитель')}
            {th('assigned_by_name', 'Автор')}
            {th('status', 'Статус')}
          </tr>
        </thead>
        <tbody>
          {sorted.map(t => {
            const isOverdue = t.due_date && t.due_date < today && t.status !== 'done';
            return (
              <tr key={t.id} onClick={() => onOpen(t)}
                className={`border-b border-primary/10 last:border-0 hover:bg-primary/3 cursor-pointer ${t.status === 'done' ? 'opacity-60' : ''}`}>
                <td className="px-3 py-2 min-w-[200px] sm:min-w-[240px]">
                  <span className="font-medium text-primary text-sm">{t.title}</span>
                  {t.description && <p className="text-xs text-primary/50 mt-0.5 line-clamp-1">{t.description}</p>}
                  {t.order_id && (
                    <button onClick={e => { e.stopPropagation(); onOpenOrder(t.order_id!); }}
                      className="mt-1 flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-accent/15 text-primary border border-accent/30 hover:bg-accent/25 transition-colors w-fit">
                      📦 {t.order_city} {t.order_customer_name}
                    </button>
                  )}
                </td>
                <td className={`px-3 py-2 text-xs font-medium whitespace-nowrap ${isOverdue ? 'text-red-500 font-bold' : 'text-primary/70'}`}>
                  {isOverdue ? '⚠️ ' : ''}{t.due_date ? fmtDate(t.due_date) : '—'}
                </td>
                <td className="px-3 py-2 whitespace-nowrap">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${PRIORITY_COLOR[t.priority]}`}>{PRIORITY_LABEL[t.priority]}</span>
                </td>
                <td className="px-3 py-2 text-xs text-primary/70 whitespace-nowrap">{t.assignee_name || 'Все'}</td>
                <td className="px-3 py-2 text-xs text-primary/50 whitespace-nowrap">{t.assigned_by_name}</td>
                <td className="px-3 py-2 whitespace-nowrap">
                  <select value={t.status} onChange={e => onUpdateStatus(t.id, e.target.value as TaskStatus)}
                    onClick={e => e.stopPropagation()}
                    className="text-[10px] border border-primary/25 rounded-lg px-1.5 py-0.5 bg-background outline-none text-primary">
                    {(Object.keys(STATUS_LABEL) as TaskStatus[]).map(s => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
                  </select>
                </td>
              </tr>
            );
          })}
          {sorted.length === 0 && (
            <tr><td colSpan={6} className="px-3 py-6 text-center text-muted-foreground text-sm">Нет задач</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

// ── Мини-календарь задач ──────────────────────────────────────────────────────
interface CalendarOrder { id: number; order_number: string; city: string; customer_name: string; total: number; due_date: string; stage: string; }

const CalendarView = ({ tasks, onUpdateStatus, onOpen, onOpenOrder, responsible }: {
  tasks: Task[];
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  onOpen: (task: Task) => void;
  onOpenOrder: (orderId: number) => void;
  responsible?: string;
}) => {
  const [currentMonth, setCurrentMonth] = useState(() => { const d = new Date(); d.setDate(1); return d; });
  const [orders, setOrders] = useState<CalendarOrder[]>([]);
  const today = new Date(); today.setHours(0,0,0,0);
  const year  = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay  = new Date(year, month + 1, 0);
  let startWd = firstDay.getDay(); startWd = startWd === 0 ? 6 : startWd - 1;
  const gridDays: (Date|null)[] = Array(startWd).fill(null);
  for (let d = 1; d <= lastDay.getDate(); d++) gridDays.push(new Date(year, month, d));
  while (gridDays.length % 7 !== 0) gridDays.push(null);
  const WEEKDAYS = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
  const [selected, setSelected] = useState<Date|null>(null);

  useEffect(() => {
    if (!responsible) return;
    (async () => {
      try {
        const res  = await fetch(urls['orders']);
        const data = await res.json();
        const filtered = (data.orders || []).filter((o: CalendarOrder & { responsible?: string; is_archived?: boolean; is_trashed?: boolean }) =>
          o.responsible === responsible && !o.is_archived && !o.is_trashed && o.due_date
        );
        setOrders(filtered);
      } catch { /* ignore */ }
    })();
  }, [responsible]);

  const isoStr = (d: Date) => d.toISOString().slice(0,10);
  const selectedTasks  = selected ? tasks.filter(t => t.due_date === isoStr(selected)) : [];
  const selectedOrders = selected ? orders.filter(o => o.due_date === isoStr(selected)) : [];

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <button onClick={() => { const d = new Date(currentMonth); d.setMonth(d.getMonth()-1); setCurrentMonth(d); }} className="px-2 py-1 rounded-lg border border-primary/30 text-primary hover:border-primary text-sm">←</button>
        <span className="font-semibold text-primary capitalize">{currentMonth.toLocaleString('ru-RU',{month:'long',year:'numeric'})}</span>
        <button onClick={() => { const d = new Date(currentMonth); d.setMonth(d.getMonth()+1); setCurrentMonth(d); }} className="px-2 py-1 rounded-lg border border-primary/30 text-primary hover:border-primary text-sm">→</button>
      </div>
      <div className="border border-primary/20 rounded-2xl overflow-x-auto">
        <div className="grid grid-cols-7 bg-primary/5 border-b border-primary/15 min-w-[560px]">
          {WEEKDAYS.map(wd => <div key={wd} className="text-center text-xs font-semibold text-primary/60 py-2">{wd}</div>)}
        </div>
        <div className="grid grid-cols-7 min-w-[560px]">
          {gridDays.map((d, i) => {
            if (!d) return <div key={i} className="min-h-[80px] border-r border-b border-primary/10 bg-primary/2" />;
            const iso = isoStr(d);
            const dayTasks  = tasks.filter(t => t.due_date === iso);
            const dayOrders = orders.filter(o => o.due_date === iso);
            const isToday    = d.getTime() === today.getTime();
            const isSelected = selected ? isoStr(selected) === iso : false;
            const isWeekend  = d.getDay() === 0 || d.getDay() === 6;
            return (
              <div key={i} onClick={() => setSelected(isSelected ? null : d)}
                className={`min-h-[80px] border-r border-b border-primary/10 p-1.5 cursor-pointer transition-colors ${isSelected ? 'bg-accent/15' : isToday ? 'bg-accent/8' : isWeekend ? 'bg-primary/2' : 'bg-background'} hover:bg-primary/5`}>
                <div className={`text-xs font-bold mb-1 ${isToday ? 'text-accent' : isWeekend ? 'text-primary/40' : 'text-primary/70'}`}>{d.getDate()}</div>
                <div className="space-y-0.5">
                  {dayTasks.slice(0,2).map(t => (
                    <div key={t.id} className={`text-[9px] px-1 py-0.5 rounded truncate font-medium ${PRIORITY_COLOR[t.priority]}`}>{t.title}</div>
                  ))}
                  {dayOrders.slice(0,2).map(o => (
                    <div key={`o${o.id}`} className="text-[9px] px-1 py-0.5 rounded truncate font-medium bg-accent/20 text-accent border border-accent/30">
                      📦 {o.city} {o.customer_name}
                    </div>
                  ))}
                  {(dayTasks.length + dayOrders.length) > 4 && <div className="text-[9px] text-primary/50">+{dayTasks.length+dayOrders.length-4}</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {(selectedTasks.length > 0 || selectedOrders.length > 0) && (
        <div className="mt-4 space-y-2">
          <div className="text-sm font-semibold text-primary">{selected!.toLocaleDateString('ru-RU',{day:'numeric',month:'long'})}</div>
          {selectedOrders.map(o => (
            <button key={`o${o.id}`} onClick={() => onOpenOrder(o.id)}
              className="w-full text-left bg-accent/10 border border-accent/30 rounded-2xl px-3 py-2 text-sm hover:bg-accent/15 transition-colors">
              <span className="font-bold text-primary">📦 {o.city} {o.customer_name}</span>
              <span className="ml-2 text-xs text-muted-foreground">#{o.order_number} · {o.stage}</span>
              <span className="ml-2 font-semibold text-primary">{o.total.toLocaleString('ru-RU')} ₽</span>
            </button>
          ))}
          {selectedTasks.map(t => <TaskCard key={t.id} task={t} onUpdateStatus={onUpdateStatus} onOpen={onOpen} onOpenOrder={onOpenOrder} />)}
        </div>
      )}
    </div>
  );
};

// ── Основной блок задач ───────────────────────────────────────────────────────
const AdminTasksBlock = ({ auth, fullPage }: { auth: AuthData; fullPage?: boolean }) => {
  const [tasks, setTasks]       = useState<Task[]>([]);
  const [requests, setRequests] = useState<TaskRequest[]>([]);
  const [staff, setStaff]       = useState<StaffOption[]>([]);
  const [tab, setTab]           = useState<TabKey>('tasks');
  const [taskSubTab, setTaskSubTab] = useState<TaskSubTab>('my');
  const [view, setView]         = useState<ViewMode>('list');
  const [staffFilter, setStaffFilter] = useState<number | ''>('');
  const [reqStaffFilter, setReqStaffFilter] = useState<number | ''>('');
  const [showDone, setShowDone] = useState(false);
  const [period, setPeriod]     = useState<PeriodFilter>('all');
  const [showTaskForm, setShowTaskForm]   = useState(false);
  const [showReqForm, setShowReqForm]     = useState(false);
  const [reviewId, setReviewId]           = useState<number | null>(null);
  const [reviewComment, setReviewComment] = useState('');

  // Детальная карточка задачи + связанный заказ
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [orders, setOrders]             = useState<Order[]>([]);
  const [ordersLoaded, setOrdersLoaded] = useState(false);
  const [fullOrder, setFullOrder]       = useState<Order | null>(null);

  const isAdmin   = auth.is_admin;
  const isManager = !isAdmin && auth.pages?.includes('access');
  const isEmployee = !isAdmin && !isManager;
  const canCreateTask = isAdmin || isManager;
  const canApprove    = isAdmin || isManager;

  const load = useCallback(async () => {
    try {
      const taskUrl = isEmployee && auth.staff_id ? `${urls['tasks']}?staff_id=${auth.staff_id}` : urls['tasks'];
      const [taskRes, reqRes, staffRes] = await Promise.all([
        fetch(taskUrl),
        fetch(`${urls['tasks']}?type=requests${isEmployee && auth.staff_id ? `&staff_id=${auth.staff_id}` : ''}`),
        fetch(urls['staff']),
      ]);
      const [taskData, reqData, staffData] = await Promise.all([taskRes.json(), reqRes.json(), staffRes.json()]);
      setTasks(taskData.tasks || []);
      setRequests(reqData.requests || []);
      setStaff((staffData.staff || []).filter((s: StaffOption) => s.is_active));
    } catch { /* сеть недоступна */ }
  }, [auth.staff_id, isEmployee]);

  useEffect(() => { load(); }, [load]);

  const createTask = async (task: Partial<Task>) => {
    await fetch(urls['tasks'], { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'task', ...task }) });
    await load();
  };
  const createRequest = async (req: Partial<TaskRequest>) => {
    await fetch(urls['tasks'], { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', ...req }) });
    await load();
  };
  const updateTaskStatus = async (id: number, status: TaskStatus) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status } : t));
    setSelectedTask(prev => prev && prev.id === id ? { ...prev, status } : prev);
    await fetch(urls['tasks'], { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'task', id, status }) });
  };
  const reviewRequest = async (id: number, status: 'approved' | 'rejected') => {
    await fetch(urls['tasks'], { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'request', id, status, reviewed_by: auth.full_name || 'Администратор', review_comment: reviewComment }) });
    setReviewId(null); setReviewComment(''); await load();
  };

  // ── Заказы: ленивая загрузка + открытие карточки заказа из задачи ────────
  const ensureOrdersLoaded = useCallback(async (): Promise<Order[]> => {
    if (ordersLoaded) return orders;
    try {
      const res  = await fetch(urls['orders']);
      const data = await res.json();
      const list: Order[] = data.orders || [];
      setOrders(list);
      setOrdersLoaded(true);
      return list;
    } catch { return orders; }
  }, [ordersLoaded, orders]);

  const openOrderFromTask = async (orderId: number) => {
    const list = await ensureOrdersLoaded();
    const found = list.find(o => o.id === orderId);
    if (found) setFullOrder(found);
  };

  const patchOrder = async (id: number, patch: Partial<Order>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...patch } : o));
    setFullOrder(prev => prev && prev.id === id ? { ...prev, ...patch } : prev);
    await fetch(urls['orders'], {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, ...patch }),
    });
  };

  const setOrderDueDate = async (orderId: number, field: 'due_date' | 'due_weaving' | 'due_painting', value: string) => {
    await patchOrder(orderId, { [field]: value } as Partial<Order>);
  };

  // Уведомления (контроль этапов заказа) отделяем от задач — их не нужно выполнять
  const notifications = tasks.filter(isNotification);
  const realTasks     = tasks.filter(t => !isNotification(t));
  const myNotifications = notifications.filter(t => t.assigned_to === auth.staff_id || !auth.staff_id);

  // Базовые фильтрации (только настоящие задачи)
  const myTasks    = realTasks.filter(t => t.assigned_to === auth.staff_id);
  const byMeTasks  = realTasks.filter(t => t.assigned_by === auth.staff_id && t.assigned_to !== auth.staff_id);
  const allTasks   = realTasks;
  const pendingReqs = requests.filter(r => r.status === 'pending');

  // Статистика
  const today = isoToday();
  const todayTasks     = realTasks.filter(t => t.due_date === today && t.status !== 'done');
  const doneTodayTasks = realTasks.filter(t => t.due_date === today && t.status === 'done');
  const overdueTasks   = realTasks.filter(t => t.due_date && t.due_date < today && t.status !== 'done');

  const getBaseTasks = () => {
    if (taskSubTab === 'my') return myTasks;
    if (taskSubTab === 'by_me') return byMeTasks;
    return allTasks;
  };

  // Применяем фильтры для задач
  const filteredTasks = useMemo(() => {
    let list = getBaseTasks();
    if (staffFilter !== '') list = list.filter(t => t.assigned_to === staffFilter || t.assigned_by === staffFilter);
    if (!showDone) list = list.filter(t => t.status !== 'done' && t.status !== 'cancelled');
    if (period !== 'all') list = list.filter(t => matchesPeriod(t, period));
    return list;
  }, [tasks, taskSubTab, staffFilter, showDone, period, auth.staff_id]);

  // Применяем фильтры для заявок
  const filteredRequests = useMemo(() => {
    if (reqStaffFilter === '') return requests;
    return requests.filter(r => r.staff_id === reqStaffFilter);
  }, [requests, reqStaffFilter]);

  // ── Мини-блок (сверху страниц, только свёрнутый) ──────────────────────────
  if (!fullPage) {
    const unreadCount = myTasks.filter(t => t.status === 'pending').length + pendingReqs.length;
    return (
      <div className="border-b-2 border-[#8a9a5a]/40 bg-[#f5f7f0]/60">
        <div className="px-6 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-[#5a6a2a]">
              <Icon name="CheckSquare" size={15} />
              <span>Задачи</span>
              {unreadCount > 0 && (
                <span className="ml-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </div>
            {/* Статистика */}
            <div className="flex items-center gap-3 text-xs text-[#5a6a2a]/80">
              {todayTasks.length > 0 && (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-400 inline-block" />
                  На сегодня: <b>{todayTasks.length}</b>
                </span>
              )}
              {doneTodayTasks.length > 0 && (
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
                  Выполнено: <b>{doneTodayTasks.length}</b>
                </span>
              )}
              {overdueTasks.length > 0 && (
                <span className="flex items-center gap-1 text-red-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                  Просрочено: <b>{overdueTasks.length}</b>
                </span>
              )}
            </div>
          </div>
          {/* Быстрые действия */}
          <div className="flex items-center gap-2">
            {canCreateTask && (
              <button onClick={() => setShowTaskForm(true)}
                className="text-xs px-3 py-1.5 rounded-xl bg-[#8a9a5a]/20 text-[#5a6a2a] hover:bg-[#8a9a5a]/30 border border-[#8a9a5a]/30 transition-colors font-medium">
                + Задача
              </button>
            )}
            {isEmployee && (
              <button onClick={() => setShowReqForm(true)}
                className="text-xs px-3 py-1.5 rounded-xl bg-[#8a9a5a]/10 text-[#5a6a2a] hover:bg-[#8a9a5a]/20 border border-[#8a9a5a]/25 transition-colors">
                Заявка
              </button>
            )}
          </div>
        </div>
        {showTaskForm && <TaskForm auth={auth} staff={staff} onSave={createTask} onClose={() => setShowTaskForm(false)} />}
        {showReqForm && <RequestForm auth={auth} onSave={createRequest} onClose={() => setShowReqForm(false)} />}
      </div>
    );
  }

  // ── Полная страница задач ──────────────────────────────────────────────────
  const MAIN_TABS: { key: TabKey; label: string; count?: number }[] = [
    { key: 'tasks',         label: 'Задачи',  count: (myTasks.length + byMeTasks.length + (isAdmin||isManager ? allTasks.filter(t=>t.assigned_to!==auth.staff_id&&t.assigned_by!==auth.staff_id).length : 0)) },
    { key: 'requests',      label: 'Заявки',  count: pendingReqs.length },
    { key: 'notifications', label: 'Уведомления', count: myNotifications.length },
  ];

  // Подвкладки задач
  const TASK_SUB_TABS: { key: TaskSubTab; label: string; count: number; adminOnly?: boolean }[] = [
    { key: 'my',    label: 'Мои задачи',        count: myTasks.filter(t=>t.status!=='done'&&t.status!=='cancelled').length },
    { key: 'by_me', label: 'Я поставил',         count: byMeTasks.filter(t=>t.status!=='done'&&t.status!=='cancelled').length },
    { key: 'all',   label: 'Задачи сотрудников', count: allTasks.filter(t=>t.status!=='done'&&t.status!=='cancelled'&&t.assigned_to!==auth.staff_id&&t.assigned_by!==auth.staff_id).length, adminOnly: true },
  ];
  const visibleSubTabs = TASK_SUB_TABS.filter(t => !t.adminOnly || isAdmin || isManager);

  const PERIODS: { key: PeriodFilter; label: string }[] = [
    { key: 'all',       label: 'Все' },
    { key: 'overdue',   label: '🔴 Просрочены' },
    { key: 'today',     label: 'Сегодня' },
    { key: 'week',      label: 'Эта неделя' },
    { key: 'next_week', label: 'След. неделя' },
    { key: 'future',    label: 'Будущее' },
  ];

  return (
    <div>
      {/* Заголовок */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <h1 className="font-display text-2xl font-semibold text-primary">Задачи</h1>
        <div className="flex gap-2">
          {canCreateTask && (
            <button onClick={() => setShowTaskForm(true)}
              className="px-4 py-2 rounded-xl bg-accent text-accent-foreground text-sm font-semibold hover:bg-accent/90 transition-colors">
              + Задача
            </button>
          )}
          {(isEmployee || canCreateTask) && (
            <button onClick={() => { setTab('requests'); setShowReqForm(true); }}
              className="px-4 py-2 rounded-xl border border-primary/40 text-primary text-sm hover:border-primary transition-colors">
              + Заявка
            </button>
          )}
        </div>
      </div>

      {/* Статистика */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="bg-card border border-primary/25 rounded-2xl px-4 py-2.5">
          <div className="text-xs text-muted-foreground">Задач на сегодня</div>
          <div className="text-xl font-bold text-primary">{todayTasks.length}</div>
        </div>
        <div className="bg-card border border-[#c8d8b0] rounded-2xl px-4 py-2.5">
          <div className="text-xs text-muted-foreground">Выполнено сегодня</div>
          <div className="text-xl font-bold text-[#5a6a2a]">{doneTodayTasks.length}</div>
        </div>
        <div className="bg-card border border-red-200 rounded-2xl px-4 py-2.5">
          <div className="text-xs text-muted-foreground">Просроченных</div>
          <div className="text-xl font-bold text-red-500">{overdueTasks.length}</div>
        </div>
      </div>

      {/* Главные вкладки */}
      <div className="flex gap-1.5 mb-0 border-b-2 border-primary/15 pb-0">
        {MAIN_TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-semibold transition-colors border-b-2 -mb-0.5 ${
              tab === t.key
                ? 'border-primary text-primary'
                : 'border-transparent text-primary/50 hover:text-primary'
            }`}>
            {t.label}
            {(t.count ?? 0) > 0 && (
              <span className={`ml-1.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full ${tab === t.key ? 'bg-primary text-white' : 'bg-primary/10 text-primary'}`}>
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Контент по вкладкам */}
      {tab === 'tasks' && (
        <div className="pt-4">
          {/* Подвкладки */}
          <div className="flex gap-1.5 mb-4 flex-wrap">
            {visibleSubTabs.map(st => (
              <button key={st.key} onClick={() => setTaskSubTab(st.key)}
                className={`px-3 py-1.5 rounded-xl border text-sm font-medium transition-colors ${
                  taskSubTab === st.key ? 'bg-primary text-white border-primary' : 'border-primary/30 text-primary hover:border-primary'
                }`}>
                {st.label}
                {st.count > 0 && (
                  <span className={`ml-1.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full ${taskSubTab === st.key ? 'bg-white/30 text-white' : 'bg-primary/10 text-primary'}`}>
                    {st.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Фильтры (только для by_me и all) */}
          {(taskSubTab === 'by_me' || taskSubTab === 'all') && (
            <div className="flex gap-3 mb-4 flex-wrap items-center bg-primary/3 rounded-2xl px-4 py-3">
              <select value={staffFilter} onChange={e => setStaffFilter(e.target.value === '' ? '' : Number(e.target.value))}
                className="border border-primary/30 rounded-xl px-3 py-1.5 text-sm outline-none focus:border-accent bg-background">
                <option value="">Все сотрудники</option>
                {staff.map(s => <option key={s.id} value={s.id}>{s.full_name}</option>)}
              </select>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <div onClick={() => setShowDone(v => !v)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${showDone ? 'bg-accent' : 'bg-primary/20'}`}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${showDone ? 'translate-x-5' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-sm text-primary">Выполненные</span>
              </label>

              <div className="flex gap-1.5 flex-wrap">
                {PERIODS.map(p => (
                  <button key={p.key} onClick={() => setPeriod(p.key)}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors ${period === p.key ? 'bg-primary text-white border-primary' : 'border-primary/25 text-primary/70 hover:border-primary'}`}>
                    {p.label}
                  </button>
                ))}
              </div>

              <div className="flex gap-1 ml-auto">
                {([['list','List'],['kanban','Columns'],['calendar','CalendarDays']] as [ViewMode, string][]).map(([v, icon]) => (
                  <button key={v} onClick={() => setView(v)}
                    className={`w-8 h-8 flex items-center justify-center rounded-lg border transition-colors ${view === v ? 'bg-primary text-white border-primary' : 'border-primary/25 text-primary/60 hover:border-primary'}`}>
                    <Icon name={icon} size={14} />
                  </button>
                ))}
              </div>
            </div>
          )}
          {/* Вид для «Мои задачи» */}
          {taskSubTab === 'my' && (
            <div className="flex gap-3 mb-4 flex-wrap items-center">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <div onClick={() => setShowDone(v => !v)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${showDone ? 'bg-accent' : 'bg-primary/20'}`}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${showDone ? 'translate-x-5' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-sm text-primary">Выполненные</span>
              </label>
              <div className="flex gap-1.5 flex-wrap">
                {PERIODS.map(p => (
                  <button key={p.key} onClick={() => setPeriod(p.key)}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors ${period === p.key ? 'bg-primary text-white border-primary' : 'border-primary/25 text-primary/70 hover:border-primary'}`}>
                    {p.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-1 ml-auto">
                {([['list','List'],['kanban','Columns'],['calendar','CalendarDays']] as [ViewMode, string][]).map(([v, icon]) => (
                  <button key={v} onClick={() => setView(v)}
                    className={`w-8 h-8 flex items-center justify-center rounded-lg border transition-colors ${view === v ? 'bg-primary text-white border-primary' : 'border-primary/25 text-primary/60 hover:border-primary'}`}>
                    <Icon name={icon} size={14} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {view === 'list'     && <ListView     tasks={filteredTasks} onUpdateStatus={updateTaskStatus} onOpen={setSelectedTask} onOpenOrder={openOrderFromTask} />}
          {view === 'kanban'   && <KanbanView   tasks={filteredTasks} onUpdateStatus={updateTaskStatus} onOpen={setSelectedTask} onOpenOrder={openOrderFromTask} />}
          {view === 'calendar' && <CalendarView tasks={filteredTasks} onUpdateStatus={updateTaskStatus} onOpen={setSelectedTask} onOpenOrder={openOrderFromTask} responsible={auth.full_name} />}
        </div>
      )}

      {tab === 'requests' && (
        <div className="pt-4">
          {/* Фильтр заявок по сотруднику */}
          {(isAdmin || isManager) && (
            <div className="flex gap-3 mb-4 items-center flex-wrap">
              <select value={reqStaffFilter} onChange={e => setReqStaffFilter(e.target.value === '' ? '' : Number(e.target.value))}
                className="border border-primary/30 rounded-xl px-3 py-1.5 text-sm outline-none focus:border-accent">
                <option value="">Все сотрудники</option>
                {staff.map(s => <option key={s.id} value={s.id}>{s.full_name}</option>)}
              </select>
              {reqStaffFilter !== '' && (
                <button onClick={() => setReqStaffFilter('')} className="text-sm text-muted-foreground hover:text-primary underline">Сбросить</button>
              )}
              <span className="text-sm text-muted-foreground">Заявок: {filteredRequests.length}</span>
            </div>
          )}
          <div className="space-y-2">
            {filteredRequests.length === 0 ? <p className="text-muted-foreground">Заявок нет</p> : filteredRequests.map(req => (
              <div key={req.id} className="bg-card border border-primary/25 rounded-2xl px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-semibold text-primary">{REQ_TYPE_LABEL[req.request_type]}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${req.status==='pending'?'bg-yellow-50 text-yellow-700':req.status==='approved'?'bg-[#f0f4e8] text-[#5a6a2a]':'bg-red-50 text-red-600'}`}>
                        {REQ_STATUS_LABEL[req.status]}
                      </span>
                    </div>
                    {(isAdmin||isManager) && <div className="text-sm text-primary/70 mb-1">{req.staff_name}</div>}
                    {(req.date_from||req.date_to) && <div className="text-sm text-primary mb-0.5">{req.date_from&&fmtDate(req.date_from)}{req.date_to&&req.date_to!==req.date_from&&` — ${fmtDate(req.date_to)}`}</div>}
                    {req.comment && <p className="text-sm text-primary/60">{req.comment}</p>}
                    {req.review_comment && <p className="text-xs text-primary/40 italic mt-1">{req.reviewed_by}: {req.review_comment}</p>}
                  </div>
                  {canApprove && req.status==='pending' && (
                    reviewId===req.id ? (
                      <div className="space-y-1 flex-shrink-0 w-44">
                        <input value={reviewComment} onChange={e=>setReviewComment(e.target.value)} placeholder="Комментарий"
                          className="w-full text-xs border border-primary/25 rounded-lg px-2 py-1 outline-none"/>
                        <div className="flex gap-1">
                          <button onClick={()=>reviewRequest(req.id,'approved')} className="flex-1 text-xs bg-[#6b7c3a] text-white rounded-lg py-1">Одобрить</button>
                          <button onClick={()=>reviewRequest(req.id,'rejected')} className="flex-1 text-xs bg-red-400 text-white rounded-lg py-1">Отклонить</button>
                          <button onClick={()=>setReviewId(null)} className="text-xs text-primary/50 px-1">✕</button>
                        </div>
                      </div>
                    ) : <button onClick={()=>setReviewId(req.id)} className="text-sm text-primary/60 hover:text-primary underline flex-shrink-0">Рассмотреть →</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'notifications' && (
        <div className="pt-4">
          <p className="text-xs text-primary/50 mb-3">
            Информация о движении заказов. Выполнять эти записи не нужно — они для контроля этапов.
          </p>
          {myNotifications.length === 0 ? (
            <p className="text-muted-foreground">Пока нет уведомлений.</p>
          ) : (
            <div className="space-y-2">
              {myNotifications.map(n => (
                <div key={n.id}
                  onClick={() => n.order_id && openOrderFromTask(n.order_id)}
                  className={`bg-card border border-primary/20 rounded-2xl px-3 py-2.5 flex items-start gap-3 ${n.order_id ? 'cursor-pointer hover:border-primary/50' : ''} transition-colors`}>
                  <span className="text-lg leading-none mt-0.5">🔔</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-primary font-medium break-words">{n.title}</div>
                    <div className="text-[11px] text-primary/45 mt-0.5">
                      {fmtDate(n.created_at)}
                      {n.order_city && ` · ${n.order_city} ${n.order_customer_name}`}
                      {n.order_number && ` · #${n.order_number}`}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showTaskForm && <TaskForm auth={auth} staff={staff} onSave={createTask} onClose={() => setShowTaskForm(false)} />}
      {showReqForm  && <RequestForm auth={auth} onSave={createRequest} onClose={() => setShowReqForm(false)} />}

      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          auth={auth}
          onClose={() => setSelectedTask(null)}
          onUpdateStatus={updateTaskStatus}
          onOpenOrder={(orderId) => { openOrderFromTask(orderId); }}
          onSetOrderDueDate={setOrderDueDate}
        />
      )}

      {fullOrder && (
        <OrderFullCard
          order={fullOrder}
          onClose={() => setFullOrder(null)}
          onUpdate={patchOrder}
        />
      )}
    </div>
  );
};

export default AdminTasksBlock;